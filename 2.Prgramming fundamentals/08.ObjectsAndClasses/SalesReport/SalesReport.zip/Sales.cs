﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesReport
{
    public class Sales
    {
        public string Town { set; get; }
        public string Product { set; get; }
        public double Price { set; get; }
        public double Quantity { set; get; }



    }
}
