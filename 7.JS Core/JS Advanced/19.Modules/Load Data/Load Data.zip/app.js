


let data = require('./data');
let sort = require('./program').sort;
let filter = require('./program').filter;


//console.log(sort('shipTo'));
//console.log(filter('status', 'shipped'));


result.sort = sort;
result.filter = filter;

