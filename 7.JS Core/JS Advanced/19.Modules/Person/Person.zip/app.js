

let Person = require('./Person.js');

result.Person = Person;




