


let mapSort = require('./helper-functions');

result.mapSort = mapSort;



/*
let map2 = new Map();
map2.set(3,"Pesho");
map2.set(1,"Gosho");
map2.set(7,"Aleks");
let sortedMap2 = mapSort(map2);
console.log(JSON.stringify([...sortedMap2]));



let map = new Map();
map.set("Stefan",true);
map.set("Azazel",false);
map.set("Bismoth",false);
map.set("Balrog",true);
map.set("Martel",true);
let sortedMap = mapSort(map);
console.log(JSON.stringify([...sortedMap]));




let map3 = new Map();
map3.set(3,{age:13,hoby:"Skiing"});
map3.set(1,{name:"Stamat",age:29,color:"blue"});
map3.set(7,{name:"Yordan",age:3});
let sortedMap3 = mapSort(map3,(a,b)=>a[1].age - b[1].age);

console.log(JSON.stringify([...sortedMap3]));
*/

