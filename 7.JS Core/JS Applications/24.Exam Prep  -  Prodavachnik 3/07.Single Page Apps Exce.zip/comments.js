
//formName.trigger('reset')    //Resetva formta.
//Kto ne razbirash dadena greska ot konzolata vij v network samata zaqvka kakvo kazva.
//kato debugvash vmeto da tursish v brawsra kude da slojish tochka, prosto napishi debugger v samiq fail !!!
//polzvai IsNaN() za proverk dali neshto e NaN.

/*
let n = undefined;
if(n === undefined)
{
    console.log("SUCCESS");
}
else
{
    console.log("Fail");
}
*/