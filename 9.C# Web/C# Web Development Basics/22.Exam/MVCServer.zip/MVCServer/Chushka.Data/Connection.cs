﻿namespace Chushka.Data
{
    public static class Connection
    {
        public static string ConnectionString = "Server=HAL\\MSSQLSERVER2;Database=ChushkaApp;Integrated Security=True;";
    }
}
