﻿namespace SimpleMvc.App.BindingModels
{
    public class LoginUserBindingModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
