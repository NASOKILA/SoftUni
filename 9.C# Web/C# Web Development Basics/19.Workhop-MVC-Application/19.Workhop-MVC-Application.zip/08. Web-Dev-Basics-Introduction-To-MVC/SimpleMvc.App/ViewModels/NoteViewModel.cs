﻿namespace SimpleMvc.App.ViewModels
{

    public class NoteViewModel
    {
        public string Title { get; set; }

        public string Content { get; set; }
    }
}
