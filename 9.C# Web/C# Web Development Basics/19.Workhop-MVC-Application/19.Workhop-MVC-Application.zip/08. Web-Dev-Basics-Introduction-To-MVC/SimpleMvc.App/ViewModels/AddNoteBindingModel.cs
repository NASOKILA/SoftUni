﻿namespace SimpleMvc.App.ViewModels
{
    public class AddNoteBindingModel
    {
        public int UserId { get; set; }

        public string Title { get; set; }

        public string Content { get; set; }
    }
}
