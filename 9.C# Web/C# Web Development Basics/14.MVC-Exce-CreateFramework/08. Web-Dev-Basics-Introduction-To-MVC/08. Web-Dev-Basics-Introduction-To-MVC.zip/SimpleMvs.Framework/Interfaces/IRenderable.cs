﻿namespace SimpleMvs.Framework.Interfaces
{

    //responsible for providing and structuring the content of a response to the server 
    public interface IRenderable
    {
        string Render();
    }
}
