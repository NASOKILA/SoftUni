﻿namespace SimpleMvs.Framework.Interfaces
{
    //responsible for calling the Render() method of a view
    public interface IInvocable
    {
        string Invoke();
    }
}
