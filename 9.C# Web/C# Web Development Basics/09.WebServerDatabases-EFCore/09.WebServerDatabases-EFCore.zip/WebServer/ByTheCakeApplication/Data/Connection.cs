﻿namespace HTTPServer.ByTheCakeApplication.Data
{
    public static class Connection
    {
        public const string ConnectionString = @"Data Source=.;Server=MSSQL\SERVER2;Database=ByTheCakeDb;Integrated Security=True";
    }
}
