﻿namespace WebServer.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post
    }
}
