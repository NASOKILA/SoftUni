﻿namespace SimpleMvs.Framework.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
