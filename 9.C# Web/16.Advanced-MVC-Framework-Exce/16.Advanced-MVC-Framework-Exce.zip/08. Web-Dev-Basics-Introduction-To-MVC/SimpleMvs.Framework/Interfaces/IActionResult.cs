﻿namespace SimpleMvs.Framework.Interfaces
{

    public interface IActionResult
    {
        string Invoke();
    }
}
