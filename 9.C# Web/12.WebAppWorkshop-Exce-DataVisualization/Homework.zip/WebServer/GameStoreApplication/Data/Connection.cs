﻿namespace HTTPServer.GameStoreApplication.Data
{
    public static class Connection
    {
        public const string ConnectionString = @"Data Source=HAL\MSSQLSERVER2;Database=GameStoreDb;Integrated Security=True";
    }
}
