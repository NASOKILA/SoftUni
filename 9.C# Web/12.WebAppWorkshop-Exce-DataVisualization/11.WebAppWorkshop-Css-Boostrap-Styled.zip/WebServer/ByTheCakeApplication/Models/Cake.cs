﻿namespace HTTPServer.ByTheCakeApplication.Models
{

    //TODO: Remove when DB if implemented

    public class Cake
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
