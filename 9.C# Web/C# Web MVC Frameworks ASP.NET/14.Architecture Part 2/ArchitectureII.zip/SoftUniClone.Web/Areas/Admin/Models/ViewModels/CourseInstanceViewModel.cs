﻿namespace SoftUniClone.Web.Areas.Admin.Models.ViewModels
{
    public class CourseInstanceViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Slug { get; set; }
    }
}
