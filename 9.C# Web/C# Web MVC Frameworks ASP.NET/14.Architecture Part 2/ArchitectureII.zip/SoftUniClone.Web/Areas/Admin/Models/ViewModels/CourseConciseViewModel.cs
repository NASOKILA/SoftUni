﻿namespace SoftUniClone.Web.Areas.Admin.Models.ViewModels
{
    public class CourseConciseViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
