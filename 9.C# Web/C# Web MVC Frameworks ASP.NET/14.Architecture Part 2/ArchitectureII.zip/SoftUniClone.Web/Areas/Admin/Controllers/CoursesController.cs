﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SoftUniClone.Data;
using SoftUniClone.Models;
using SoftUniClone.Web.Areas.Admin.Models.BindingModels;
using SoftUniClone.Web.Areas.Admin.Models.ViewModels;
using SoftUniClone.Web.Helpers.Messages;
using System.Collections.Generic;
using System.Linq;

namespace SoftUniClone.Web.Areas.Admin.Controllers
{
    public class CoursesController : AdminController
    {
        private readonly SoftUniCloneContext context;
        private readonly IMapper mapper;

        public CoursesController(
            SoftUniCloneContext context,
            IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var courses = this.context.Courses.ToList();
            var model = this.mapper.Map<IEnumerable<CourseConciseViewModel>>(courses);
            return View(model);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(CourseCreationBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            var course = this.mapper.Map<Course>(model);
            this.context.Courses.Add(course);
            context.SaveChanges();
            // TODO: redirect to details

            this.TempData["__Message"] = new MessageModel()
            {
                Type = MessageType.Success,
                Message = "Course created successfully."
            };
            return RedirectToAction("Details");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            // TODO: Add lecturer
            var course = this.context.Courses
                .Include(c => c.Instances)
                .FirstOrDefault(c => c.Id == id);
            var model = this.mapper.Map<CourseDetailsViewModel>(course);
            return View(model);
        }
    }
}