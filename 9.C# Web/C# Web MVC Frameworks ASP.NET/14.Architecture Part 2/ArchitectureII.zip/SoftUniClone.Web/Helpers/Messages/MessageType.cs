﻿namespace SoftUniClone.Web.Helpers.Messages
{
    public enum MessageType
    {
        Success,
        Info,
        Warning,
        Danger
    }
}
