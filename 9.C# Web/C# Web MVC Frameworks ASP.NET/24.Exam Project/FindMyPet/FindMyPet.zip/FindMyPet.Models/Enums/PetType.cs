﻿namespace FindMyPet.Models.Enums
{
    public enum PetType
    {
        Bird = 1,
        Dog = 2,
        Cat = 3
    }
}
