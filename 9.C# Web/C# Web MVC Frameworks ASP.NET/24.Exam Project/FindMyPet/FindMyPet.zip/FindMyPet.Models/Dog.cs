﻿namespace FindMyPet.Models
{
    public class Dog : Pet
    {
        public bool HatesCats { get; set; }

        public bool IsFrendyToPeople { get; set; }
    }
}
