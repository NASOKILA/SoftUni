﻿namespace FindMyPet.Models
{
    public class Cat : Pet
    {
        public bool ClimbsOnTrees { get; set; }

        public bool HatesMouses { get; set; }
    }
}
