﻿namespace FindMyPet.Web.Static
{
    public static class ExternalLoginIds
    {
        public const string FacebookAppId = "1876435669108247";
        public const string FacebookAppSecret = "eb4f529f5e7fd09f06ae4c94bd592656";

        public const string GoogleClientId = "303515638916-cns6mv23v2q29qsb0eevtvm0k98nlkvs.apps.googleusercontent.com";
        public const string GoogleClientSecret = "7EJAVz4lCFGvCxMzmqk-SkSi";
    }
}
