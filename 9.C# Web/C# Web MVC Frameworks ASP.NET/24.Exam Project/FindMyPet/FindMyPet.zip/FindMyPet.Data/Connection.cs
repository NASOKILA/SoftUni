﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FindMyPet.Data
{
    public static class Connection
    {
        public const string ConnectionString = "Data Source =.; Database=FindMyPet;Trusted_Connection=True;Integrated Security = True";
    }
}
