﻿namespace HTTPServer.ByTheCakeApplication.Data
{
    public static class Connection
    {
        public const string ConnectionString = @"Data Source=.;Server=HAL\MSSQLSERVER2;Database=ByTheCakeDb;Integrated Security=True";
    }
}
