﻿namespace HTTPServer.Server.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post
    }
}
