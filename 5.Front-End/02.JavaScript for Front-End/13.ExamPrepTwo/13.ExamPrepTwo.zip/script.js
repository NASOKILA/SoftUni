
/*
    ZADACHITE SA RESHENI I SA VUV FAILOVETE
        ProblemOne.js,
        ProblemTwo.js,
        ProblemThree.js,
        ProblemFour.js


    IZVINQVAM SE ZA ZAKUSNENIETO  :)

*/