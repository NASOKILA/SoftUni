/**
 * Created by user on 11/11/2017.
 */


function solve(args)
{

    for(let i = 0; i <= args.length; i++)
    {
        if (args[i] === "Stop")
            return;

        console.log(args[i]);
    }
}

//solve(['Line 1', 'Line 2', 'Line 3', 'Stop']);


solve(['3', '6', '5', '4', 'Stop', '10', '12']);















