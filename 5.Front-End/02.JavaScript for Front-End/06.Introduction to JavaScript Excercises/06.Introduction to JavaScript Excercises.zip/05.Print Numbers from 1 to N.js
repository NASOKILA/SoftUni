/**
 * Created by user on 11/11/2017.
 */



function solve(args)
{

    for(let i = 1; i<= Number(args[0]); i++)
    {
        console.log(i);
    }
}

//solve(['5']);

solve(['2']);








