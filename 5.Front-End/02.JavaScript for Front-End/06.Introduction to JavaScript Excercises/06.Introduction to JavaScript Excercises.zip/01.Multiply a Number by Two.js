


function solve(args)
{
    let result = Number(args);
    console.log(result * 2);
}

solve(['2']);

solve(['3']);

solve(['30']);

solve(['13']);


















