/**
 * Created by user on 11/11/2017.
 */


function solve(args)
{

    for(let i = Number(args[0]); i>= 1; i--)
    {
        console.log(i);
    }
}

//solve(['5']);

solve(['2']);






