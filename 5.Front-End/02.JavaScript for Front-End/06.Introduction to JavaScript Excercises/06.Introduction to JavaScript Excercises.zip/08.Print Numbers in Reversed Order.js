/**
 * Created by user on 11/11/2017.
 */



function solve(args)
{
    for(let arg of args.reverse())
    {
        console.log(arg);
    }
}

// solve(['10','15','20']);

//solve(['5','5.5','24','-3']);

solve(['20','1','20','1','20']);










