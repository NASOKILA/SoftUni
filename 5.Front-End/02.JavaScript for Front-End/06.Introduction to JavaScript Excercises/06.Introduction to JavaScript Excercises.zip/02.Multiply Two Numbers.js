/**
 * Created by user on 11/11/2017.
 */

function solve(args)
{
    let x = args[0];
    let y = args[1];

    let result = Number(x) * Number(y);
     console.log(result);
}
solve(['2','3']);

solve(['13','13']);

solve(['1','2']);

solve(['0','50']);






