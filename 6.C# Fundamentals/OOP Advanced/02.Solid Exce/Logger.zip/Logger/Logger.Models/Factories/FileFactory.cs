﻿namespace Logger.Models.Factories
{
    public class FileFactory
    {
    }
}
