﻿namespace Logger.Models
{
    public enum ErrorLevel
    {
        //opisvame kakvi greshki moje da imame
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
