﻿using System;
using System.Text;
using Last_Army.Core;
using Last_Army.IO;

namespace Last_Army
{
    class LastArmyMain
    {
        static void Main()
        {

            string input = ConsoleReader.ReadLine();
            GameController gameController = new GameController();
            StringBuilder result = new StringBuilder();


            Engine engine = new Engine(result, input, gameController);

            engine.Run();
          
        }
    }
}