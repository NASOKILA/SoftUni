﻿
using Last_Army.Core;
using Last_Army.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Engine
{

    private string input = "";
    private GameController gameController;
    private StringBuilder result;

    public Engine(StringBuilder result, string input, GameController gameController)
    {
        this.input = input;
        this.gameController = gameController;
        this.result = result;
    }


    public void Run()
    {
        while (!input.Equals("Enough! Pull back!"))
        {
            try
            {
                gameController.GiveInputToGameController(input);
            }
            catch (ArgumentException arg)
            {
                result.AppendLine(arg.Message);
            }
            input = ConsoleReader.ReadLine();
        }

        gameController.RequestResult(result);
        ConsoleWriter.WriteLine(result.ToString());
    }


}

