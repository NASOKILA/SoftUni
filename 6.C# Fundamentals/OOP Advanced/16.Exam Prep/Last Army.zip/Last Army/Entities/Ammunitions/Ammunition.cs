﻿

public abstract class Ammunition
{

    public Ammunition(string name, double weight)
    {
        this.Name = name;
        this.Weight = weight;
    }

    public string Name { get; }

    public double Weight { get; }
}
