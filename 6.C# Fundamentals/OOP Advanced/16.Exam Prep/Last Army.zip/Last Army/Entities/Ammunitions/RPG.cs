﻿
public class RPG : Ammunition
{
    public const double Weight = 17.1;

    public RPG(string name)
        : base(name, Weight)
    {
    }
}
