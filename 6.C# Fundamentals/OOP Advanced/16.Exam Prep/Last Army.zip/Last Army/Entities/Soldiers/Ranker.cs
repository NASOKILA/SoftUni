﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Ranker : Soldier
{
    public Ranker(string Name, int Age, double Experience, double Endurance, double OverallSkill, 
        IDictionary<string, IAmmunition> Weapons) 
        : base(Name, Age, Experience, Endurance, OverallSkill, Weapons)
    {
    }

    protected override IReadOnlyList<string> WeaponsAllowed => throw new NotImplementedException();
}

