﻿using System.Collections.Generic;
using System.Text;

namespace Last_Army
{
    public class SpecialForce : Soldier
    {
        private const double OverallSkillMiltiplier = 3.5;

        private readonly List<string> weaponsAllowed = new List<string>
        {
            "Gun",
            "AutomaticMachine",
            "MachineGun",
            "RPG",
            "Helmet",
            "Knife",
            "NightVision"
        };

        public SpecialForce(string Name, int Age, double Experience,
            double Endurance, double OverallSkill, IDictionary<string, IAmmunition> Weapons)
            : base(Name, Age, Experience, Endurance, OverallSkill, Weapons)
        {
        }

        protected override IReadOnlyList<string> WeaponsAllowed => throw new System.NotImplementedException();

    }
}