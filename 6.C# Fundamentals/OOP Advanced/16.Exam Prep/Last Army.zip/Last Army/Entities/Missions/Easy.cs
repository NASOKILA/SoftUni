﻿
public class Easy : Mission
{
    public Easy(double ScoreToComplete) 
        :base(20, ScoreToComplete)
    {}

}

