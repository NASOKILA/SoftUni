﻿
public class Hard : Mission
{
    public Hard(double ScoreToComplete) 
        : base(80, ScoreToComplete)
    {}

}

