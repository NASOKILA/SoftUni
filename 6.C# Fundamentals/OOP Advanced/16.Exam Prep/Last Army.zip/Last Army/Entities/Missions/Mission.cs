﻿
public abstract class Mission
{

    public Mission(double EnduranceRequired, double ScoreToComplete)
    {
        this.EnduranceRequired = EnduranceRequired;
        this.ScoreToComplete = ScoreToComplete,
    }

    
    public double EnduranceRequired { get; }

    public double ScoreToComplete { get; }
    
}

