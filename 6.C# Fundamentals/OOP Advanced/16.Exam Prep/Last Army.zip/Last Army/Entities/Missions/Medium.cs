﻿
public class Medium : Mission
{
    public Medium(, double ScoreToComplete) 
        : base(50, ScoreToComplete)
    {}

}

