﻿
public class NightVision : Ammunition
{
    private const double weight = 0.8;

    public override double Weight => weight;
}
