﻿
public class AutomaticMachine : Ammunition
{
    private const double weight = 6.3;//po uslovie trqbva da imame konstanta

    public override double Weight => weight;

}