﻿public interface IConsoleReader
{
    string ReadLine();
}

