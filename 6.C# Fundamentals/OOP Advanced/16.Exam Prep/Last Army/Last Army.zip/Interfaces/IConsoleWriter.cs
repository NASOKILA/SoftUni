﻿public interface IConsoleWriter
{
    void AppendLine(string line);

    void WriteLineAll();
}