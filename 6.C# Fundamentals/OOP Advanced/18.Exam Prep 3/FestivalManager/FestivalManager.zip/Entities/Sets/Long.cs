﻿
namespace FestivalManager.Entities.Sets
{
    
    public class Long : Set
    {
        public Long(string name) 
            : base(name, 60)
        {}
    }
}
