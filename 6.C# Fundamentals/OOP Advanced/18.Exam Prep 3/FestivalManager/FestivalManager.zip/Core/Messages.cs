﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Core
{
    public static class Messages
    {
        public const string SetRegistered = "Registered {0} set";

        public const string PerformerRegistered = "Registered performer {0}";

    }
}
