﻿namespace Forum.App.Contracts
{
	using Models;

    public interface IPositionable
    {
        Position Position { get; }
    }
}
