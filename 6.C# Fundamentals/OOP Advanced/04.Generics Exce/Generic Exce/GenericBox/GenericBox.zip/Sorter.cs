﻿using System;
using System.Collections.Generic;
using System.Text;


public class Sorter : CustomList<string>
{
    public static void Sort(CustomList<string> list)
    {
        list.Sort();
    }

}

