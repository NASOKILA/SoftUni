﻿using System;
using System.Collections.Generic;
using System.Text;


public class Command : ICommand
{
    public void Execute()
    {
        throw new NotImplementedException();
    }
}

