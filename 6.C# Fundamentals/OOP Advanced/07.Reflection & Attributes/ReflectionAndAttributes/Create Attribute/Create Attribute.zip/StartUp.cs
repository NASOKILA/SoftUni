﻿using System;

//Atributa se kazva "SoftUniAttribute" no nie go izvikvame samo s "SoftUni"
//S tozi atribut pokzvame primerno koi kakvo e rabotl po proekta.
//Mojem da imame mnogo takiva atribute zashtoto moje mnogo hora da sa rabotili vurhu edno i sushto neshto po proekta.
[SoftUni("Ventsi")]
[SoftUni("Nasko")]
[SoftUni("Asi")]
public class StartUp
{ 

    [SoftUni("Gosho")]
    static void Main(string[] args)
    {
    }
}


