﻿using System;


[SoftUni("Ventsi")]
public class StartUp
{

    //AKO NAPISHEM POVECHE ATRIBUTI SHTE S POKAJAT VSICHKITE
    //[SoftUni("Nasko")]
    //[SoftUni("Asi")]
    [SoftUni("Gosho")]
    public static void Main(string[] args)
    {
        Tracker.PrintMethodsByAuthor();
    }
}

