﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_KingsGambit.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
