﻿namespace P03_DependencyInversion
{
    using P03_DependencyInversion.contrasts;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        static void Main(string[] args)
        {
            PrimitiveCalculator calculator = new PrimitiveCalculator(new AdditionStrategy());

            string input = "";
            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input.Split().ToArray();
                string command = tokens[0];

                if (command == "mode")
                {
                    char @operator = char.Parse(tokens[1]);
                    IStrategy strategyToChange = FindStrategy(@operator);
                    calculator.changeStrategy(strategyToChange);
                }
                else
                {
                    int numberOne = int.Parse(command);
                    int numberTwo = int.Parse(tokens[1]);
                    Console.WriteLine(calculator.performCalculation(numberOne, numberTwo));
                }

            }

        }

        public static IStrategy FindStrategy(char @operator)
        {
            IStrategy strategyToChange = null; 

            switch (@operator)
            {
                case '+':
                    strategyToChange = new AdditionStrategy();
                    break;
                case '-':
                    strategyToChange = new SubtractionStrategy();
                    break;
                case '*':
                    strategyToChange = new MultiplicationStrategy();
                    break;
                case '/':
                    strategyToChange = new DivisionStrategy();
                    break;
                default:
                    throw new ArgumentException($"Invalid operator {@operator} !");
            }

            return strategyToChange;

        }

    }
}
