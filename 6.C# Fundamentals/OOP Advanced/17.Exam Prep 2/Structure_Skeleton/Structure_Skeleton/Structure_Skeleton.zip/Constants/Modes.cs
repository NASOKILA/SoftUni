﻿
public class Modes
{
    public const string FullMode = "Full";

    public const string HalfMode = "Half";

    public const string EnergyMode = "Energy";
}

