﻿

public class StandartProvider : Provider
{
    public StandartProvider(int ID, double energyOutput)
        : base(ID, energyOutput)
    { }
}

