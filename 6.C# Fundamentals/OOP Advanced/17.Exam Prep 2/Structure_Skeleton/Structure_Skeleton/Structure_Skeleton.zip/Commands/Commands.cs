﻿
public static class Commands
{
    public const string RegisterHarvesterCommand = "RegisterHarvester";

    public const string RegisterProviderCommand = "RegisterProvider";

    public const string DayCommand = "Day";

    public const string ModeCommand = "Mode";

    public const string InspectCommand = "Inspect";

    public const string RepairCommand = "Repair";

    public const string ShutDownCommand = "Shutdown";
}

