﻿using System;
using System.Collections.Generic;
using System.Text;


public class Cat : Animal
{
    public Cat(string name, string favoriteFood) 
        : base(name, favoriteFood)
    {}

    public override string ExplainSelf()
    {
        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"I am {this.Name} and my fovourite food is {this.FavoriteFood}");
        sb.AppendLine("MEEOW");

        return sb.ToString().TrimEnd();
    }

}

