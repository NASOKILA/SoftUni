﻿using System;
using System.Collections.Generic;
using System.Text;

//ZA JUDGE MAAME NAMESPACE-a I PISHEM KLASA DA E public

public class BankAccount
{
    private int id;
    private decimal balance;

    public int Id
    {
        get { return this.id; }
        set
        {
            id = value;
        }
    }

    public decimal Balance
    {
        get { return this.balance; }
        set
        {
            balance = value;
        }
    }

    public void Deposit(decimal amount)
    {
        this.balance += amount;
    }

    public void Withdraw(decimal amount)
    {
        this.balance -= amount;
    }

    //override ToString() method
    public override string ToString()
    {
        return $"Account {this.id}, balance {this.balance}";
    }
}
