﻿using System;

//ZA JUDGE MAHAME NAMESPACE-a

class Program
{
    static void Main(string[] args)
    {
        BankAccount acc = new BankAccount();

        acc.Id = 1;
        acc.Deposit(15);
        acc.Withdraw(10);

       // Console.WriteLine($"Account {acc.ID}, balance {acc.Balance}");

        //Console.WriteLine(acc.ToString());
        //moje direktno da se izvika sus acc
        Console.WriteLine(acc);

    }
}

