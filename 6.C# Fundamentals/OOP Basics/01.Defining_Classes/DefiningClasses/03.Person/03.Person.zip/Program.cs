﻿using System;

class Program
{
    static void Main(string[] args)
    {


        var bankAccountOne = new BankAccount();
        bankAccountOne.Id = 1;
        

    }
}

