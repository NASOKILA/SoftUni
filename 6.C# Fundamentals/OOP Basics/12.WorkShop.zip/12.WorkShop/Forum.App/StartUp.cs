﻿namespace Forum.App
{
	public class StartUp
	{
		public static void Main(string[] args)
		{
            //Pravim Engine Obekt i izvikvame funkciqta Rum() loeto go startira
			Engine engine = new Engine();
			engine.Run();
		}
	}
}


