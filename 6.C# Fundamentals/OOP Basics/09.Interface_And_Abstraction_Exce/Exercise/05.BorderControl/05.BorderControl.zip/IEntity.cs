﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IEntity
{
    string Id { get; set; }
}

