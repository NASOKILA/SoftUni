﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IEntity
{
    string Name { get; set; }

    string Id { get; set; }

    string Birthdate { get; set; }
}

