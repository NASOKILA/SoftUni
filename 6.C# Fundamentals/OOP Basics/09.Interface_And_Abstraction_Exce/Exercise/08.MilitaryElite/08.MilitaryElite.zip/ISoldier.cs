﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ISoldier
{
    int Id { get; }

    string FirtName { get; }

    string LastName { get; }
    
}

