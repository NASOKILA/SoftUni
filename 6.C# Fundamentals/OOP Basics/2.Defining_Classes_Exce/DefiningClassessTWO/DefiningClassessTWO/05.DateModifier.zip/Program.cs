﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {

        string dateOne = Console.ReadLine().Replace(" ", "/");
        string dateTwo = Console.ReadLine().Replace(" ", "/");

        DateModifier dateModifier = new DateModifier();

        string result = dateModifier.FindDeference(dateOne, dateTwo);

        Console.WriteLine(result);
    }
}

