﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        Family family = new Family();

        for (int i = 0; i < n; i++)
        {
            string[] input = Console.ReadLine()
                .Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                .ToArray(); ;

            string name = input[0];
            int age = int.Parse(input[1]);

            Person person = new Person(name, age);

            family.AddMember(person);
        }


        List<Person> peopleOverThirty = family.GetOverPeopleThirty();

        peopleOverThirty.ForEach(p =>
        {

            Console.WriteLine(p.Name + " - " + p.Age);

        });
        
    }
}

