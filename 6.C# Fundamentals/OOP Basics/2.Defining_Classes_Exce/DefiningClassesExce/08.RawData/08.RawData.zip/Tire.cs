﻿public class Tire
{
    public Tire(double tirePresure, int tireAge)
    {
        this.TirePressure = tirePresure;
        this.TireAge = tireAge;
    }

    public double TirePressure { get; set; }

    public int TireAge { get; set; }
}

