﻿using System;

public class Children
{
    public Children()
    {}

    public string ChildName { get; set; }

    public DateTime ChildBirthday { get; set; }
}