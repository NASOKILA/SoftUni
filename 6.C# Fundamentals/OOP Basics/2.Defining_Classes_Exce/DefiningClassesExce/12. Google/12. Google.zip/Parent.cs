﻿using System;

public class Parent
{
    public Parent()
    {}

    public string ParentName { get; set; }

    public DateTime parentBirthday { get; set; }
}