﻿public class Company
{
    public Company()
    {}

    public string CompanyName { get; set; }

    public string Department { get; set; }

    public decimal Salary { get; set; }
}