﻿public class Car
{
    public Car()
    {}

    public string CarModel { get; set; }

    public int CarSpeed { get; set; }
}