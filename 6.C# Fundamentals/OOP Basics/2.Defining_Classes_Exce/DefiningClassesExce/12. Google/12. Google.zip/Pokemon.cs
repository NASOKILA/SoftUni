﻿public class Pokemon
{

    public Pokemon()
    {}

    public string pokemonName { get; set; }

    public string pokemonType { get; set; }
}