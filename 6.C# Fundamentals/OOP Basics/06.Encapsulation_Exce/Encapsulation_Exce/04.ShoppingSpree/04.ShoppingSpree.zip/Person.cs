﻿using System;
using System.Collections.Generic;
using System.Text;


public class Person
{
    private string name;
    private decimal money;

    public string Name
    {
        get { return name; }
        set
        {
            name = value;

            if (name == null || name == string.Empty || name == " ")
            {
                throw new ArgumentException("Name cannot be empty");
            }
        }
    }

    public decimal Money
    {
        get { return money; }
        set
        {
            money = value;

            if (money < 0)
                throw new ArgumentException("Money cannot be negative");
        }
    }


    private List<Product> products;

    public List<Product> Products
    {
        get { return products; }
        set { products = value; }
    }

    public Person()
    {}

    public Person(string name, decimal money)
    {
        this.Name = name;
        this.Money = money;
        this.Products = new List<Product>();
    }


}

