﻿using System;
using System.Collections.Generic;
using System.Text;


public class Stat
{
    private string name;
    private int valueOfStat;

    public int ValueOfStat
    {
        get { return valueOfStat; }
        set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException(($"{this.Name} should be between 0 and 100."));
            }

            valueOfStat = value;
        }
    }
    
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public Stat()
    {}

    public Stat(string name, int valueOfStat)
    {
        this.Name = name;
        this.ValueOfStat = valueOfStat;
    }
}

