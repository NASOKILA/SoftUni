﻿using System;
using System.Collections.Generic;
using System.Text;


//Pravim si enum i mu kazvame che e int, moje da e double, long, decimal i dr.
public enum DiscountType:int
{
    None,    
    SecondVisit = 10,
    VIP = 20
}




    