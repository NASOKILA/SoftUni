﻿using System;
using System.Collections.Generic;
using System.Text;


public enum Seasons:int
{
    Autumn = 1,
    Spring = 2,
    Winter = 3,
    Summer = 4
}

