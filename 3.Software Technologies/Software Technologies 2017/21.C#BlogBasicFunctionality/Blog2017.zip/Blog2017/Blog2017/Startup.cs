﻿using Blog2017.Migrations;
using Blog2017.Models;
using Microsoft.Owin;
using Owin;
using System.Data.Entity;

[assembly: OwinStartupAttribute(typeof(Blog2017.Startup))]
namespace Blog2017
{
    public partial class Startup
    {

        // TOZI FAIL STARTIRA PRIOJENIETO, NESHTO KATO Main METODA V KONZOLNITE PRILOJENIQ
        public void Configuration(IAppBuilder app)
        {

            //ZA DA MIGRIRAME BAZATA TRQBVA DA NAISHEM:
            Database.SetInitializer(
                new MigrateDatabaseToLatestVersion<BlogDbContext, Configuration>());
           

            ConfigureAuth(app);

        }
    }
}
