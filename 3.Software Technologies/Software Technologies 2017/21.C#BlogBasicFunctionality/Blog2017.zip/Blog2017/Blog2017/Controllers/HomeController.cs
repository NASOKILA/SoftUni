﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Blog2017.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //SHTE GO NAPRAVIM TAKA CHE DA REDIREKTVA KUM INDEX METODA V ARTILE CONTROLLERA
            return RedirectToAction("Index", "Article");
        }

     
    }
}