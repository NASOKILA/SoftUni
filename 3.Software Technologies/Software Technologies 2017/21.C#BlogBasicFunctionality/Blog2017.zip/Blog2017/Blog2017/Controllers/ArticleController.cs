﻿using Blog2017.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using Microsoft.AspNet.Identity;

namespace Blog2017.Controllers
{
    public class ArticleController : Controller
    {
        // GET: Article
        public ActionResult Index()
        {
            // SEGA SHTE LISTNEM VSICHKI ARTIKULI NA INDEX STRANICATA

            var db = new BlogDbContext(); // Vzimame bazata

            var articles = db.Articles
                .Include(a => a.Author) // DOBAVQME SI AVTORA NO ZA DA STANE TQBVA DA INCLUDNEM using System.Data.Entity;
                .ToList(); // vzimame vschki artikuli ot bazata kato list
                                              


            return View(articles); // podavame go na view s ime Index 
        }

        [HttpGet]
        [Authorize]
        public ActionResult Create()
        {

            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult Create(Article article)
        {
            if(ModelState.IsValid)
            {
                //Trqbva da si setnem avtora :

                string userId = User.Identity.GetUserId(); // VZIMAME SI USER ID-to
                article.AuthorId = userId; // I G OSETVAME NA NOVIQ ARTIKUL

                var db = new BlogDbContext();

                db.Articles.Add(article);
                db.SaveChanges();
                //DOBAVQME KUM BAZATA I SEIVAME !!!

                //redirektvame si kum Index 
                return RedirectToAction("Index");

            }

            //Ako e nevalidno si redirektvame pak kum tova view na koeto sme v momenta !!!
            return View();

        }

        [HttpGet]
        [Authorize]
        public ActionResult Delete(int? id)
        {
            
            // priema id koeto se polzva v linka za triene na dedena statiq, SLAGAME DA MOJE DA E NULL INACHE SHTE GRUMNE
            var db = new BlogDbContext();
            var article = db.Articles
                .Where(a => a.Id == id)
                .FirstOrDefault();

            if (article == null)
            {
                return HttpNotFound();
            }

            if (article.AuthorId == User.Identity.GetUserId())
            {
                return View(article);
            }

            return RedirectToAction("Login", "Account");


            
        }

        [HttpPost]
        [Authorize]
        public ActionResult Delete(Article article)
        {
            if (article == null)
            {
                return HttpNotFound();
            }

            // priema id koeto se polzva v linka za triene na dedena statiq, SLAGAME DA MOJE DA E NULL INACHE SHTE GRUMNE
            var db = new BlogDbContext();

            // TRQBVA DA GO NAPRAVIM TAKA CHE SAMO NIE DA MOJEM DA SI TRIEM STATIITE
            var articleToRemove = db.Articles.Find(article.Id);

         
                db.Articles.Remove(articleToRemove);
                db.SaveChanges();
                return RedirectToAction("Index");
                 
        }

        [HttpGet]
        [Authorize]
        public ActionResult Edit(int? id) {

           
            BlogDbContext db = new BlogDbContext();
            Article article = db.Articles
                .Where(a => a.Id == id)
                .FirstOrDefault();

            if (article == null)
            {
                return HttpNotFound();
            }

          
                //we find the user by id
                var author = db.Users.Find(article.AuthorId);
                article.Author = author;
                //Trqbva da mu setna i Author da e = na usera koito go e napisal
                

                return View(article);
            
        }

        [HttpPost]
        [Authorize]
        public ActionResult Edit(Article article)
        {

            if (article == null)
            {
                return HttpNotFound();
            }

            if (ModelState.IsValid)
            {

                var db = new BlogDbContext();

                // vzimame si stariq artikul ot bazata  
                var prevArticle = db.Articles
                    .FirstOrDefault(a => a.Id == article.Id);

                // setvame properties na stariq da sa = na tezi ot noviq 
                prevArticle.Title = article.Title;
                prevArticle.Content = article.Content;
                prevArticle.Date = DateTime.Now;        // Setvame si is datata da e kato segashnata !!!!
                prevArticle.AuthorId = User.Identity.GetUserId();
                prevArticle.Author = db.Users.Find(article.AuthorId);

                //Setvame sustoqnieto na artikula kato promeneno !!!
                db.Entry(prevArticle).State = EntityState.Modified;
                db.SaveChanges();

                // datata avtomatichno se pravi
                
                return RedirectToAction("Index");
            }

            return View();
        }


    }
}