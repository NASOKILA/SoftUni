﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Blog2017.Models
{
    public class Article
    {
       

        [Key] // DORI I DA NE MU GO SLOJIM TOVA Key TO SHTE SE DOSETI AVTOMATICHNO CHE E KLUCH
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Title { get; set; }

        [Required]
        public string Content { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public Article()
        {
            // Pravim si konstruktor koito avtomatichno ni setva datata na segashnata
            //taka i davame defaultna stoinosto
            //Za vseki nov artikul
            this.Date = DateTime.Now;
        }

        public string AuthorId { get; set; }

        public ApplicationUser Author { get; set; }

    }
}