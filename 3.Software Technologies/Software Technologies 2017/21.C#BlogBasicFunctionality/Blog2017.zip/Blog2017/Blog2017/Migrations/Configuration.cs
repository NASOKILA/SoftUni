namespace Blog2017.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Blog2017.Models.BlogDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            // KOGATO IMA RAZLIA MEJDU BAZATA I KOLONITE, NAPRAVI MIGRACIQ T.E. PROMENI KOLONITE !

            //TRQBVA DA DOBAVIM SLEDNOTO
            AutomaticMigrationDataLossAllowed = true;
            // S TOVA KAZVAME CHE RAZRESHAVAME DA SMENQ BAZATA DANNI DORI I DA IZGUBIM DANNI !

        }

        protected override void Seed(Blog2017.Models.BlogDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
        }
    }
}
