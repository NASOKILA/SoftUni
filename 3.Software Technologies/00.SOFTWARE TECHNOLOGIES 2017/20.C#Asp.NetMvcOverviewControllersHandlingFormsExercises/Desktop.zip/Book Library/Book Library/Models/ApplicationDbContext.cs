﻿using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;
using System.Collections;

namespace Book_Library.Models
{

    // V TOZI FAIL NIE SI EXTRAKTVAME BAZTA
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public IEnumerable ApplicationUsers { get; internal set; }

        // Dbset<> e specialen klas v (EF) koito raboti kato list zashtoto e kolekciq
        // nie tuk kazvame che e ot tip Book i SHTE DURJI NASHITE KNIGI V BAZATA KATO KOLEKCIQ.
        public virtual DbSet<Book> Books { get; set; }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}


