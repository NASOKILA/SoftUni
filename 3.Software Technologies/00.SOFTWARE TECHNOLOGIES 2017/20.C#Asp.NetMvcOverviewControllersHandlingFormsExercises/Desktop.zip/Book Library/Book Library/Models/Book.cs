﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Book_Library.Models
{
    public class Book
    {
        // PRAVIM SI BOOK MODELA

        // v relacionnite bazi e nujno da imame Id za da mojem da razlichavame edin obekt ot drug
        public int Id { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        // Tova ni trqbva ako iskame da setvame avtor na neshto bez da e nujno da durpame cqliq avtor ot bazata
        public string AuthorId { get; set; }

        // AVTORA TRQBVA DA E OT TIP USER
        public ApplicationUser Author { get; set; }
    }
}