﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Book_Library.Models;
using Microsoft.AspNet.Identity;

namespace Book_Library.Controllers
{
    public class BooksController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Books
        public ActionResult Index()
        {

            // ZA DA VIJDAME I AVTORA NA VSICHKI TEZI KNIGI TRQBVA DA GO INCLUDNEM  
            var books = db.Books.Include(b => b.Author);

            // podavame vsichki knigi kum viewto i ako dobavim nova kniga tq shte se prisuidin kum drugite !!!
            return View(books.ToList());
        }

        // GET: Books/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                // ako imame Id = na Null znchi vrushtame Suobshtenie
                return new HttpNotFoundResult("ID of the book equalt null !");
            }

            //Vzimame Informavciqta za avtora  I SE ZAPULVA V book
            Book book = db.Books
                .Include(b => b.Author)
                .Single(b => b.Id == id); // Single() AKO NAMERI POVECHE OT EDIN VRUSHTA EXCEPTION
            // AKO POLZVAME First() AKO NAMERI POVECHE OT EDIN VRUSHTA PURVIQ


            // AKO NE SME AVTORA NA TAZI KNIGA SHTE GO NAPRAVIM DA NI REDIREKTVA KUM LOGIN PAGEa
            if (book.AuthorId != User.Identity.GetUserId())
            {
                return new HttpUnauthorizedResult("You have to be the author of this book to be able to see the details !");
            }

            // SEGA book SUDURJA I INFORMACIQTA ZA AVTORA KATO FULLNAME, ID I EMAIL KOETO ISKAME DA POKAJEM NA VIEWTO
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        // GET: Books/Create
        [HttpGet]
        [Authorize]  // trqbva da sme lognati
        public ActionResult Create()
        {
            return View();
        }   

        // POST: Books/Create
        [HttpPost]  // slusha za post zaqvki
        [Authorize] // tezi koito ne sa lognati ne moje da pravat knigi
        [ValidateAntiForgeryToken]    // trqbva tokena da e validen
        public ActionResult Create([Bind(Include = "Id,Title,Description,AuthorId")] Book book)
        {
            if (ModelState.IsValid)
            {
                // AKO PODADENOTO OT USERA E VALIDNO
                
                // SETVAME AuthorId DA E = NA Id-to na tekushtiq user
                book.AuthorId = User.Identity.GetUserId();

                // DOBAVQME KNIGATA V BAZATA
                db.Books.Add(book);
                db.SaveChanges();

                // redirektvame kum index metoda koito gi podava knigite na viewto kato spisuk ot knigi
                return RedirectToAction("Index");
            }

           // Ako podadenata nova kniga ot formata e nevalidna znachi prosto vrushtame sushtoto view
            return View(book);
        }

        // GET: Books/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            // i tuk si includvame AuthorId inache nqma da mojem da vijdame nishto svurzano s avtora
            Book book = db.Books
                .Include(b => b.Author)
                .SingleOrDefault(b => b.Id == id);

            if (book == null)
            {
                return HttpNotFound("Cannot Find Book !");
            }


            // TUK AKO NE SME AVTORA NA TAZI KNIGA SHTE GO NAPRAVIM DA NI REDIREKTVA KUM LOGIN PAGEa
            if (book.AuthorId != User.Identity.GetUserId())
            {
                return new HttpUnauthorizedResult("You have to be the author of this book to be able to edit it !");
            }


            return View(book);
        }

        // POST: Books/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Description,AuthorId")] Book book)
        {
            if (ModelState.IsValid)
            {

                if (book.Title == null || book.Description == null)
                {
                    // Ako zglavieto ili opisanieto na knigata koqto promenqme e praznio znachi pak vrushtme sushtata stranica !
                    return View(book);
                }

                // Dobavqme s ii avtora na knigata inache shte go izgubim pri prezapisvaneto na edna kniga

                book.AuthorId = User.Identity.GetUserId();
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AuthorId = new SelectList(db.ApplicationUsers, "Id", "FullName", book.AuthorId);
            return View(book);
        }

        // GET: Books/Delete/5
        [Authorize]
        [HttpGet]
        public ActionResult Delete(int? id)
        {
            // Vzimame si knigata
            Book book = db.Books.Find(id);

            // AKO NIE NE SME AVTORA NA TAZI KNIGA DA NE MOJEM DA Q IZTRIEM
            if (book.AuthorId != User.Identity.GetUserId())
            {
                return RedirectToAction("Index");
            }


            // ako Idto e null vrushtame bad Request
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
         //ako nqma kniga s takova id vrushtame che ne mojem da q namerim !
            if (book == null)
            {
                return HttpNotFound($"Cannot find the book with id {id} !");
            }
            

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")] // Tuk kazvame che actiona se kazva Delete dori i dolo da pishe deleteConfirmed
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            
            Book book = db.Books.Find(id);     // Namirame si knigata 
            db.Books.Remove(book);   // triqm q ot bazata
            db.SaveChanges();        // Seivame bazata
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
