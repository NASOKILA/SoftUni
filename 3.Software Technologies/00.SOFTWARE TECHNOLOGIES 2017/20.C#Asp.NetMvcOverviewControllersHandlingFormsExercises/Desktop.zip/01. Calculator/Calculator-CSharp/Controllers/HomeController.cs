﻿using Calculator_CSharp.Models;
using System.Web.Mvc;
using System;

namespace Calculator_CSharp.Controllers
{
    public class HomeController : Controller
    {
        //need to modify our Index action to recime a calculator and 
        //to return an instance of our Calculator model. 
       
        public ActionResult Index(Calculator calculator)
        {
            
            return View(calculator);
            // returns Index.cshtml insade the views/home folder.
            // Visual Studio is smart.
            /* 
                url-ite RABOTQT TAKA: "{controller}/{action}/{id}"
                Viewto se namira v Views/Article Papkata
                OPISANO E V RouteConfig.cs
             */
        }


        // Pravim si Actiona koito shte ni napravi presmqtaneto
        [HttpPost]
        public ActionResult Calculate(Calculator calculator)
        {
            // vzimame si resultata
            calculator.Result = CalculateResult(calculator);

            // podavame kalkulatora na Index actiona koito shte go podade na viewto.
            return RedirectToAction("Index", calculator);
        }

        private decimal CalculateResult(Calculator calculator)
        {
            // EVERITHING FROM THE FORM IS ALREADI PARSED
            decimal result = 0m;
            switch (calculator.Operator)
            {
                case "+":
                    result = calculator.LeftOperand + calculator.RightOperand;
                    break;
                case "-":
                    result = calculator.LeftOperand - calculator.RightOperand;
                    break;
                case "*":
                    result = calculator.LeftOperand * calculator.RightOperand;
                    break;
                case "/":
                    result = calculator.LeftOperand / calculator.RightOperand;
                    break;

            }


            return result;

        }
    }
}














