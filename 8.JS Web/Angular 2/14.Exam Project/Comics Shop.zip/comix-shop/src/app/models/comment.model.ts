export class CommentModel {
    public _id: string;
    public description: string;
    public creator: string;
    public date: string;
    public comixId: string;
}