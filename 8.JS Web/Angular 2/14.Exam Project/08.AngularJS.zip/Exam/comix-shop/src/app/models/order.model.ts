export class OrderModel {
    constructor(
        public comix: string,
        public date: string,
        public buyer: string,
        public price: string) { }
}
