
export class UserModel {
 
    public message : string;
    public success : boolean;
    public token : string;
    public user : any;
}
