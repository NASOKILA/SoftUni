
module.exports = (req, res) => {
  if (req.pathname === '/generateImage' && req.method === 'POST') {

      

  } else {
    return true
  }
}
