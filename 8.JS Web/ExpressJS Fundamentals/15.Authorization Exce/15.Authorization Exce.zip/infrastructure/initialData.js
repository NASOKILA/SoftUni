module.exports = {
    user: {  
        '_id': '5b1d074d45e81335e84af257',
        'username':'user',
        'password': 'password',
        'rentedCars': [ ]
    },
    cars: [
        {
            '_id': '5b1d074d45e81335e84af258',
            'make': 'KIA',
            'model': 'Magentis',
            'color': 'Blue',
            'imageUrl': 'https://parkers-images.bauersecure.com/pagefiles/194507/cut-out/600x400/magentis-03.jpg',
        },
        {
            '_id': '5a1d074d45e81335e84af257',
            'make': 'Aston Martin',
            'model': 'RX',
            'color': 'silver',
            'imageUrl': 'http://www.motorplanextender.co.za/images/Motor%20Plan%20Extender%20Aston%20Martin.jpg'
        },
        {
            '_id': '6b1d074d45e81335e84af257',
            'make': 'Ford',
            'model': 'GT 500',
            'imageUrl': 'https://ccmarketplace.azureedge.net/cc-temp/listing/104/1601/10210745-1967-ford-mustang-shelby-gt500-std-c.jpg' 
        }
    ]
};