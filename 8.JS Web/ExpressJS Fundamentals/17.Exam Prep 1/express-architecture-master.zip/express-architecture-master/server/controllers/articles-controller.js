module.exports = {
  create: (req, res) => {
    res.send('CREATE ARTICLE')
  }
}
