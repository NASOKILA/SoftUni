export default {
    defaultState: {
        content: '',
        postId: ''
    }
}