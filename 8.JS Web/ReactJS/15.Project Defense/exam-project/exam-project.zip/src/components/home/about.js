import React from 'react';

export default class About extends React.Component {

    render() {
        return (
            <div>
            <br/>
                <h1>Welcome to House Shop</h1>
                <hr className="hr-1 bg-white"/>
                <p>Buy interesting houses and discuss great content.</p>
                <p>It's what's happening now.</p>
                <p>Sign in or sign up in a second.</p>
            </div>
        )
    }
}
