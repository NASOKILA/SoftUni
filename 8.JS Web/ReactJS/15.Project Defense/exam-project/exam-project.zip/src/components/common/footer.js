import React, { Component } from 'react'

export default class Footer extends Component {

    render() {


        return (
            <footer>
                <div className="footerDiv container-fluid chushka-bg-color">
                    <div className="text-white p-2 text-center">
                        &copy; CopyRight Sanity Web Design Studios 2018. All rights reserved.
                </div>
                </div>
            </footer>
        )
    }
}