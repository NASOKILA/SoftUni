
/*
    V kinvey ima Roles i mojem da suzdavame roli i posle da gi slagame na useri.

    void(0)  v JS oznachava da ne pravi nishto, polzva se poveche pri linkove.


    VAJNOOOOOOOOOOOOOOOOOOOOOOOOO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    Mojem da suddem normaen komponent i da polzvame texsta v nego po sledniq nachin:
    <MyComponent>
        Some Text ...
    </MyComponent>

    Textut se vzima sus: {this.props.children}  

    Ako nqmame children vrushta null,
    ako imame edin element go vrushta nego, a a ko imame mnogo childreni
        togava vrushta kolekciq.

    VAJNOOOOOOOOO!!!!!!!!!!!!!!!!!
    Ako imame tagove v drugi tagove, znachi vurtreshnite tagove sa vuv props.children
        na purviq tag. 


        VAJOOOOOOOOOO!!!!!!!!!!!!!!!!!!!!!!!!!
            Object.assign({}, {name:"Atanas", age:25});
            Sus Object.assign() kopirame nehtata ot vtoriq obekt i gi slagamev nov

    */



