import React from 'react';

export default class Details extends React.Component {
    render = () => (
            <section id="bio">
                <div className="image">
                    <img src=/>
                </div>
                <div className="info">
                    <p>Name: <strong></strong></p>
                    <p>Bio:</p>
                    <p></p>
                </div>
            </section>
        )
}