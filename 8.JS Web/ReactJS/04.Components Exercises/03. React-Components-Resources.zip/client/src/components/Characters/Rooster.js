import React from 'react';

export default class Rooster extends React.Component {
    render = () => {
        return (
            <section id="roster">
                
            </section>
        )
    }
}