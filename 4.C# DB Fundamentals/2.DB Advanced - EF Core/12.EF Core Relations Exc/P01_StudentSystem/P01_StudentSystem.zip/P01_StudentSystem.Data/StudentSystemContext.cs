﻿namespace P01_StudentSystem.Data
{
    using System;
    using Microsoft.EntityFrameworkCore;
    using P01_StudentSystem.Data.Models;

    public class StudentSystemContext : DbContext
    {

        //Konstruktori
        public StudentSystemContext()
        {

        }

        public StudentSystemContext(DbContextOptions options)
            :base(options)
        {

        }


        //DbSetove
        public DbSet<Course> Courses { get; set; }

        public DbSet<Homework> Homework { get; set; }

        public DbSet<Resource> Resources { get; set; }

        public DbSet<Student> Students { get; set; }

        public DbSet<StudentCourse> StudentsCourses { get; set; }


        //Configure ConnectionString   OnConfiguring()
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            if (!builder.IsConfigured)
            {
                builder.UseSqlServer(@"Server=HAL\MSSQLSERVER2; Database=Student System;Integrated Security=True;");
            }
        }


        //override OnModelCreating()      Fluent API
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //Student
            modelBuilder.Entity<Student>(entity => {

                //vruzki i kluchove
                entity.HasKey(s => s.StudentId);
                
/*
                entity.HasMany(s => s.StudentCourses)
                    .WithOne(sc => sc.Student)
                    .HasForeignKey(sc => sc.StudentId);
*/
                entity.HasMany(s => s.HomeworkSubmissions)
                    .WithOne(hs => hs.Student)
                    .HasForeignKey(hs => hs.StudentId);

                //Propertita
                entity.Property(s => s.Name)
                    .HasMaxLength(100)
                    .IsUnicode(true)
                    .IsRequired(true);

                entity.Property(s => s.PhoneNumber)
                    .IsUnicode(false)
                    .IsRequired(false);

                entity.Property(s => s.RegisteredOn)
                    .IsRequired(true);

                entity.Property(s => s.BirthDay)
                    .IsRequired(false);

            });


            //Course
            modelBuilder.Entity<Course>(entity => {

                //vruzki i kluchove
                entity.HasKey(c => c.CourseId);
                
                /*
                entity.HasMany(c => c.StudentCourses)
                    .WithOne(sc => sc.Course)
                    .HasForeignKey(sc => sc.CourseId);
                */

                entity.HasMany(c => c.HomeworkSubmissions)
                    .WithOne(hs => hs.Course)
                    .HasForeignKey(hs => hs.CourseId);

                entity.HasMany(c => c.Resources)
                    .WithOne(r => r.Course)
                    .HasForeignKey(r => r.CourseId);

                //Propertita
                entity.Property(c => c.Name)
                    .HasMaxLength(80)
                    .IsUnicode(true)
                    .IsRequired(true);

                entity.Property(c => c.Description)
                    .IsUnicode(true)
                    .IsRequired(false);

                entity.Property(c => c.StartDate)
                    .IsRequired(true);

                entity.Property(c => c.EndDate)
                    .IsRequired(true);

                entity.Property(c => c.Price)
                    .IsRequired(true);

            });


            //StudentCourse Mapping Table
            modelBuilder.Entity<StudentCourse>(entity => {

                entity.HasKey(sc => new {
                   sc.StudentId,
                   sc.CourseId
                });

                entity.HasOne(sc => sc.Course)
                    .WithMany(c => c.StudentCourses)
                    .HasForeignKey(sc => sc.CourseId);

                entity.HasOne(sc => sc.Student)
                    .WithMany(c => c.StudentCourses)
                    .HasForeignKey(sc => sc.StudentId);

            });


            //Homework
            modelBuilder.Entity<Homework>(entity => {

                //kluchove i vruzki
                entity.HasKey(h => h.HomeworkId);

                entity.HasOne(h => h.Course)
                    .WithMany(c => c.HomeworkSubmissions)
                    .HasForeignKey(h => h.CourseId);

                entity.HasOne(h => h.Student)
                    .WithMany(c => c.HomeworkSubmissions)
                    .HasForeignKey(h => h.StudentId);

                //propertita
                entity.Property(h => h.Content)
                    .IsUnicode(false)
                    .IsRequired(true);
                //Ne znam kak da go naprava da e linkable kum fail

                entity.Property(h => h.ContentType)
                    .IsRequired(true);

                entity.Property(h => h.SubmissionTime)
                    .IsRequired(true);
                
            });


            //Resourses
            modelBuilder.Entity<Resource>(entity => {

                //kluchove i vruzki
                entity.HasKey(r => r.ResourseId);

                entity.HasOne(r => r.Course)
                    .WithMany(c => c.Resources)
                    .HasForeignKey(r => r.CourseId);


                //Propertita
                entity.Property(r => r.Name)
                    .HasMaxLength(50)
                    .IsUnicode(true)
                    .IsRequired(true);

                entity.Property(r => r.Url)
                    .IsUnicode(false)
                    .IsRequired(true);

                entity.Property(r => r.ResourceType)
                    .IsRequired(true);

            });

        }


    }
}
