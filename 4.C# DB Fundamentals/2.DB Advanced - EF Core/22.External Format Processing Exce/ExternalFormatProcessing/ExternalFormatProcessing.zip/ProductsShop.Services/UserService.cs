﻿namespace ProductsShop.Services
{
    using System;

    public class UserService
    {
    }
}
