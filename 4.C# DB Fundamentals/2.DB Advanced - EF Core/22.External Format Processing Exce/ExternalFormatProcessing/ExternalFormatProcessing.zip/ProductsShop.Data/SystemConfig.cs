﻿namespace ProductsShop.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class SystemConfig
    {
        public static string connectionString =  @"Server=HAL\MSSQLSERVER2; Database=ProductsShop; Integrated Security=True;";
    }
}
