﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        //S tochka ne stawa
        internal static string ConnectionString => @"Server=HAL\MSSQLSERVER2;Database=Instagraph;Integrated Security=True;";
    }
}
