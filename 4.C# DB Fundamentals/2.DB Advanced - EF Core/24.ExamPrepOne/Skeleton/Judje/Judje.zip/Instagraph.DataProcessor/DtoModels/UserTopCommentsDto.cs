﻿namespace Instagraph.DataProcessor.DtoModels
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class UserTopCommentsDto
    {
        public string  Username { get; set; }

        public int MostComments { get; set; }
    }
}
