﻿namespace Instagraph.DataProcessor.DtoModels
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class UserDto
    {
        public string Username { get; set; }

        public string Password { get; set; }

        //TRQBVA ZADULJITELNO TOVA IME DA E SUSHTOTO
        public string ProfilePicture { get; set; }
    }
}
