﻿namespace Instagraph.DataProcessor.DtoModels
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class FollowerDto
    {
        public string User { get; set; }

        public string Follower { get; set; }
    }
}
