﻿namespace Instagraph.DataProcessor.DtoModels
{
    public class UserFollowerDto
    {
        public string User { get; set; }
        public string Follower { get; set; }
    }
}
