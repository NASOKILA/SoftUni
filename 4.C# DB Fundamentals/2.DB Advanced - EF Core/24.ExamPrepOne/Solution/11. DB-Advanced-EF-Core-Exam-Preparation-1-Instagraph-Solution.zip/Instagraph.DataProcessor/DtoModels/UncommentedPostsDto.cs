﻿namespace Instagraph.DataProcessor.DtoModels
{
    public class UncommentedPostDto
    {
        public int Id { get; set; }
        public string Picture { get; set; }
        public string User { get; set; }
    }
}
