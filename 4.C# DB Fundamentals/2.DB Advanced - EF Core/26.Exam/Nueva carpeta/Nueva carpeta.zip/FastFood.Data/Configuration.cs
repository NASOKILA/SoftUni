namespace FastFood.Data
{
	public static class Configuration
	{
        //S tochna ne stava

		public static string ConnectionString = @"Server=HAL\MSSQLSERVER2;Database=FastFood;Trusted_Connection=True";
	}
}