﻿namespace PhotoShare.Client
{
    using PhotoShare.Models;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Session
    {
        public static User User { get; set; }
    }
}
