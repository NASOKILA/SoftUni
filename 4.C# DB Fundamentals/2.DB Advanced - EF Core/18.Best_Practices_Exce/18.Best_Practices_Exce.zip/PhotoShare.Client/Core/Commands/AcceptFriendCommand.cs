﻿namespace PhotoShare.Client.Core.Commands
{
    using System;

    public class AcceptFriendCommand
    {
        // AcceptFriend <username1> <username2>
        public static string Execute(string[] data)
        {

            //Taq ne q razbrah !

            return "Taq komanda ne q razbrah !";
        }
    }
}
