﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        //Change to  .  before submitting
        internal static string ConnectionString => "Server=HAL\\MSSQLSERVER2;Database=PhotoShare;Integrated Security=True;";
    }
}
