﻿
using P01_HospitalDatabase;

namespace P01_HospitalDatabase
{


    public class StartUp
    {
        static void Main(string[] args)
        {
            /*
             Paketa .tools trqbva da tam kudeto ni e StartUp Proekta.
             */

            //SLED KATO VSICHKO NI E SUZDADENO SI VDIGAME BAZATA

            /*
             TOVA NI TRQBVASHE ZA PURVA ZADACHA.

            using (var db = new HospitalContext())
            {
                //S tazi komanda si q suzdavames
                db.Database.EnsureCreated(); 
            }
            */



            /*
             SLED KAto VDIGNAHME BAZATA SI PTAVIM Migraciq,
                 dobavqme komandata Add-Migration ImeNaMigraciq
            

            AKO POLZVAME GENERATORA KOITO NI E DADEN:
                DatabaseInitializer.ResetDatabase();
                TOVA RESETVA BAZATA S NOVITE MIGRACII, SEGA NQMA NUJDA DA 
                Q DROPVAME I POSLE DA Q UPDEITVAME !!!

                I POSLE VKARVAME PACIENTI !!!

             */
             
            
        }
    }
}
