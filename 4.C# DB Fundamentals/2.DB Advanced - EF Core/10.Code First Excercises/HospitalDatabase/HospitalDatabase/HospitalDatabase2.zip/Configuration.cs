﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase
{
    public class Configuration
    {
        public const string connectionString 
            = @"Server=HAL\MSSQLSERVER2;Database=Hospital;Integrated Security=True";
    }
}
