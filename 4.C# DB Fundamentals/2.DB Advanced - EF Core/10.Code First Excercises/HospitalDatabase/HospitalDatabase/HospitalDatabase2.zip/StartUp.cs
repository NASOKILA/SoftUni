﻿
using P01_HospitalDatabase.Data;

namespace P01_HospitalDatabase
{


    public class StartUp
    {
        static void Main(string[] args)
        {
            /*
             Paketa .tools trqbva da tam kudeto ni e StartUp Proekta.
             */


            //SLED KATO VSICHKO NI E SUZDADENO SI VDIGAME BAZATA
            using (var db = new HospitalContext())
            {
                //S tazi komanda si q suzdavames
                db.Database.EnsureCreated(); 
            }

        }
    }
}
