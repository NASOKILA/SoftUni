﻿namespace P03_SalesDatabase.Data.Models
{

    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class Product
    {
        public Product()
        {

        }

        [Key]
        public int ProductId { get; set; }

        public string Name { get; set; }

        //Tova e ot zdacha 4
        public string Description { get; set; }

        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public Sale Sale { get; set; }
    }
}
