﻿namespace P03_SalesDatabase
{
    using P03_SalesDatabase.Data;
    using System;

    public class Program
    {
        static void Main(string[] args)
        {
            using (var db = new SalesContext())
            {


                //NE STAVA KATO NAPISHA updata-database I ZATOVA PRAVA TAKA !!!

                db.Database.EnsureDeleted();
                //Suzdavame si bazata kato runvame programata
                db.Database.EnsureCreated();
            }
        }
    }
}
