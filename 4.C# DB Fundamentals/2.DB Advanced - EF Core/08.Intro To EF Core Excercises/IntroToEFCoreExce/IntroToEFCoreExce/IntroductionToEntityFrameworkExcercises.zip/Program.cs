﻿using P02_DatabaseFirst.Data;
using P02_DatabaseFirst.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace P02_DatabaseFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}