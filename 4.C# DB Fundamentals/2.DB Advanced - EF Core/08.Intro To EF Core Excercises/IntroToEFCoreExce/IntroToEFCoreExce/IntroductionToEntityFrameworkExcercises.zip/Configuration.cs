﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst
{
    public class Configuration
    {
        public const string connsctionString = @"Server=HAL\MSSQLSERVER2;Database=SoftUni;Integrated Security=True;";
    }
}
