﻿namespace TeamBuilder.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Gender
    {
        Male,
        Female
    }
}
