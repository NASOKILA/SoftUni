﻿namespace TeamBuilder.App
{
    using System;

    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
