﻿namespace TeamBuilder.Client
{
    using TeamBuilder.Models;

    public class Session
    {
        public static User User { get; set; }
    }
}
