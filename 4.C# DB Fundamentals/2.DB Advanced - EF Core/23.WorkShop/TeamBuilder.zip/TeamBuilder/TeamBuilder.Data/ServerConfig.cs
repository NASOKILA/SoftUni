﻿namespace TeamBuilder.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    internal class ServerConfig
    {
        internal static string connectionString = @"Server=HAL\MSSQLSERVER2; Database=TeamBuilder; Integrated Security=True;";
    }
}
