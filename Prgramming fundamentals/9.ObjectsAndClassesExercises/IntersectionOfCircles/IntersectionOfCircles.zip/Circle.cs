﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntersectionOfCircles
{
    class Circle
    {
        public int centerPointX { set; get; }
        public int centerPointY { set; get; }
        public int radius { set; get; }

    }
}
