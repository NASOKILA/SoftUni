﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AndreyAndBilliard
{
    public class AndreyAndBilliard
    {
        public static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            Dictionary<string, double> Shop = new Dictionary<string, double>();
            SetShop(n, Shop);


            string clients = Console.ReadLine();
            List<Costumer> CostumerShopList = new List<Costumer>();            
            SetCostumerShopList(clients, CostumerShopList, Shop);


            PrintClientProductQuantityAndBill(CostumerShopList, Shop);    


        }

        private static void PrintClientProductQuantityAndBill(List<Costumer> CostumerShopList, Dictionary<string, double> Shop)
        {
            double totalBill = 0;
            foreach (var Client in CostumerShopList.OrderBy(x => x.Name))
            {
                string product = "";
                double quantity = 0;
                
                Console.WriteLine(Client.Name);              // client name
                foreach (var item in Client.BougthProductAndQuantity)
                {
                    product = item.Key;
                    quantity = item.Value;
                    Console.WriteLine("-- {0} - {1}", item.Key, item.Value);   //What the cliend bougth and the quantity
                }

                double fullBill = quantity * Shop[product];
                totalBill += fullBill;
                Console.WriteLine("Bill: {0:f2}", fullBill);// the bill the client paid
                
            }
            Console.WriteLine("Total bill: {0}",totalBill);
        }

        private static void SetCostumerShopList( string clients, List<Costumer> CostumerShopList,
            Dictionary<string, double> Shop)
        {
            
            char[] separator = { '-', ',' };

            while (!clients.Equals("end of clients"))
            {

                string[] NameProductQuantity = clients.Split(separator).ToArray();
                string name = NameProductQuantity[0];
                string product = NameProductQuantity[1];
                double quantity = double.Parse(NameProductQuantity[2]);

                if (Shop.ContainsKey(product))         // Ako nqma takuv produkt v Shopa da mine na sledvashtiq
                {


                    Dictionary<string, double> ProductQuantity = new Dictionary<string, double>();
                    ProductQuantity[product] = quantity;

                    Costumer client = new Costumer
                    {

                        Name = name,
                        BougthProductAndQuantity = ProductQuantity,

                    };

                    CostumerShopList.Add(client);     // dobavqme si klienta v spisuka !

                    clients = Console.ReadLine();
                }
                else
                    clients = Console.ReadLine();

                
            }


        }

        private static void SetShop(int n, Dictionary<string, double> Shop)
        {
            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split('-').ToArray();
                string product = input[0];
                double price = double.Parse(input[1]);

                if (price > 9)
                    price = double.Parse(input[1]) / 100 ;

                Shop[product] = price;

            }
        }
    }
}
